﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIFinalTask
{
    public class Course
    {
        public required string CourseName { get; set; }
        public int CreditPoints { get; set; }

    }
}
